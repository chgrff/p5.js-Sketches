class SpiralShape {
  constructor(Red = 0, Green = 0, Blue = 0, strokeWeightValue = 6) {
    this.Red = Red;
    this.Green = Green;
    this.Blue = Blue;
    this.volHistory = [];
    this.strokeWeightValue = strokeWeightValue;
  }

  display() {
    noFill();
    stroke(this.Red, this.Green, this.Blue); // Set stroke color based on provided values or default 
    strokeWeight(this.strokeWeightValue);

    if (this.volHistory.length > 0) {
      beginShape();
      for (let i = 0; i < this.volHistory.length; i++) {
        let x = this.volHistory[i] * cos(i);
        let y = this.volHistory[i] * sin(i);
        vertex(x, y);
      }
      endShape();
    } 
  }
}
