
class circleClass {
  
  constructor(xCoord, yCoord, size, colorValueR,colorValueG,colorValueB) {
    this.posX = xCoord;
    this.posY = yCoord;
    this.size = size;
    this.fillcolorR = colorValueR;
    this.fillcolorG = colorValueG;
    this.fillcolorB = colorValueB;
  }
  
  update(){
    
    noStroke();
    fill(this.fillcolorR,this.fillcolorG,this.fillcolorB);
    circle(this.posX,this.posY,this.size);
    
  }
}