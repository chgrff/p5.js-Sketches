let img, moonimg, sun, bg, earthSize;

function preload() {
  // https://www.solarsystemscope.com/textures/
  img = loadImage("2k_earthDAY.jpg");
  moonimg = loadImage("2k_moon.jpg");
  core = loadImage("2k_sun.jpg");
  bg = loadImage("8k_Milk.jpg");

  earthSize = 100;
}

function setup() {
  createCanvas(960, 600, WEBGL);
}

function draw() {
  background(0);

  //directional light for Earth and Moon
  push();
  directionalLight(255, 255, 255, mouseX - 300, mouseY - 300, -500);

  //Earth's Crust
  push();
  texture(img);
  noStroke();
  smooth();
  rotateY(frameCount * 0.01);
  sphere(earthSize);
  pop();

  //moon
  push();
  texture(moonimg);
  noStroke();
  rotateY(frameCount * 0.01); //27 days for an orbit, 0.01/27
  translate(300, 0, 0); //300 is 1/10th the 'real' distance
  sphere(earthSize * 0.27); //our moon is ~27% the size of Earth
  pop();

  pop();

  //outer and inner core
  push();
  rotateY(frameCount * -0.001)
  texture(core);
  noStroke();
  sphere(40);
  fill(185);
  sphere(15);
  pop();

  //our sky sphere
  push();
  ambientLight(200);
  texture(bg);
  noStroke();
  sphere(4000);
  pop();

  //move
  orbitControl();
}
