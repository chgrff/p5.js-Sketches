//baseline variables for math 
let angle = 0;
let radius = 10;

function setup() {
  
  //the "generative" elements
  changeRadius= random(0.2,2)
  angleIncrement = random(0.1,100);
  changeSize= random(30,70)
  
  //choose a random color
  fillcolorR=random(0,255);
  fillcolorG=random(0,255);
  fillcolorB=random(0,255);
  
  //Canvas
  createCanvas(500, 500);
  background(255);
  
}

function draw() {
  
  // Move the origin to the center of the canvas
  translate(width / 2, height / 2); 
  
  //This is a way to increment a circular path into a spiral (thx ChatGPT) 
  angle += angleIncrement;
  radius += changeRadius; 
  
  //assign x and y to a spiraling equation
  let x = radius * cos(angle);
  let y = radius * sin(angle);
  
  ball = new circleClass(
    x,y,changeSize,fillcolorR,fillcolorG,fillcolorB)
  
  invertedball = new circleClass(
    -(x),-(y),changeSize,fillcolorR,fillcolorG,fillcolorB)
  
  ball.update()
  invertedball.update()
  
  //increment the fill color to white as it moves out
  fillcolorR += 0.5
  fillcolorG += 0.5
  fillcolorB += 0.5
  
}

function keyPressed() {
  if (key === ' ') {
    filter(INVERT)
  }
}
