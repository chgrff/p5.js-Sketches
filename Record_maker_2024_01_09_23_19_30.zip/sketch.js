//This sketch is a skewmorphic represenation of a vinyl record, taking any sound and producing a spiraling waveform based on the amplitude that evokes the appearance of the vinyl medium. This sketch also allows you to bring in the album art for the sound you choose, the script then calculates the average color of the album's cover art and uses that as the background color. Feel free to zoom in and out with the mouse to explore the waveform as it is being produced.

//Currently playing: "bad idea right?" by: Olivia Rodrigo

let sound, amp;
let volHistory = []; //array to store time

let angle = 0;
let songDuration, angleIncrement, radChange, ampChange; //Math

let avgRed = 0;
let avgGreen = 0;
let avgBlue = 0;

let running = true; // Boolean for the drawing to end

let audio = "Olivia/bad idea right.mp3"; // Choose your audio file

let img; // coresponding album art

function preload() {
  sound = loadSound(audio);
  img = loadImage("Images/GUTS.jpg");
}

function setup() {
  createCanvas(1000, 1000, WEBGL); // Create a WebGL canvas
  sound.play();
  // sound.setVolume(0.2); //Volume set to 50%

  amp = new p5.Amplitude();
  amp.setInput(sound); //getting our waveform

  songDuration = sound.duration();
  angleIncrement = 360 / songDuration; //One rotation per song
  frameRate(angleIncrement * 6); //Multiply for desired amount of rotation

  //store to change in script
  radChange = 0;
  ampChange = 0;

  // Calculate average color from the image
  //(https://editor.p5js.org/aferriss/sketches/x4W77PZVI) 44-56
  img.loadPixels();
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      const index = (y * img.width + x) * 4;
      avgRed += img.pixels[index];
      avgGreen += img.pixels[index + 1];
      avgBlue += img.pixels[index + 2];  } 
  }
  
  img.updatePixels();
  
  const numPixels = img.pixels.length / 4;
  avgRed /= numPixels; avgGreen /= numPixels; avgBlue /= numPixels;
}

function draw() {
  angleMode(DEGREES);
  orbitControl((sensitivityZ = 0)); //you can move in/out no rotate

  if (running == true) {
    background(avgRed, avgGreen, avgBlue);

    let vol = amp.getLevel();
    let r = map(vol, 0, 1,
      int(80 + radChange), //Increases radius (spiral)
      int(110 + ampChange) //Incrementally increase the amp max as we move out
    );

    volHistory.push(r); //append volHistory with amp and location

    //center art
    noFill(); // Set the fill to transparent
    strokeWeight(3);
    stroke(255); // Set the stroke color to white
    circle(0, 0, 150); // Draw outlined circle

    // Apply the image texture within a circular boundary using WebGL
    push();
    texture(img);
    circle(0, 0, 150);
    pop();

    //spiral shapes

    let mySpiralA = new SpiralShape(255, 255, 255, 10); //outline
    mySpiralA.volHistory = volHistory.slice();
    mySpiralA.display();

    let mySpiralB = new SpiralShape(avgRed, avgGreen, avgBlue, 8); //fill
    mySpiralB.volHistory = volHistory.slice();
    mySpiralB.display();

    let mySpiralC = new SpiralShape(255, 255, 255, 2); //center
    mySpiralC.volHistory = volHistory.slice();
    mySpiralC.display();

    if (volHistory.length > 1) {
      radChange += 1 / 8; // Increase radius
      ampChange += 1 / 6; //Increase amp to eliminate smoothing on outer rings
    }

    if (sound.currentTime() >= songDuration - 0.1) {
      running = false; // When sound stops, stop drawing
    }
  }
}
